-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2017 at 11:19 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lifecoac_lifecoaching`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_commentmeta`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_commentmeta' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_commentmeta`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_comments`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_comments' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_comments`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_folders`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_folders' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_folders`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_galleries`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_galleries' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_galleries`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_galleries_excluded`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_galleries_excluded' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_galleries_excluded`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_galleries_resources`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_galleries_resources' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_galleries_resources`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_photos`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_photos' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_photos`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_photos_pos`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_photos_pos' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_photos_pos`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_photos_settings`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_photos_settings' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_photos_settings`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_settings_presets`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_settings_presets' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_settings_presets`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_settings_sets`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_settings_sets' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_settings_sets`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_stats`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_stats' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_stats`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_gg_tags`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_gg_tags' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_gg_tags`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_links`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_links' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_links`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_options`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_options' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_options`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_postmeta`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_postmeta' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_postmeta`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_posts`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_posts' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_posts`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_revslider_css`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_revslider_css' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_revslider_css`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_revslider_layer_animations`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_revslider_layer_animations' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_revslider_layer_animations`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_revslider_navigations`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_revslider_navigations' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_revslider_navigations`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_revslider_sliders`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_revslider_sliders' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_revslider_sliders`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_revslider_slides`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_revslider_slides' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_revslider_slides`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_revslider_static_slides`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_revslider_static_slides' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_revslider_static_slides`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_termmeta`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_termmeta' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_termmeta`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_terms`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_terms' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_terms`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_relationships`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_term_relationships' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_term_relationships`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_term_taxonomy`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_term_taxonomy' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_term_taxonomy`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_usermeta`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_usermeta' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_usermeta`' at line 1)

-- --------------------------------------------------------

--
-- Table structure for table `wp_users`
--
-- in use(#1932 - Table 'lifecoac_lifecoaching.wp_users' doesn't exist in engine)
-- Error reading data: (#1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'FROM `lifecoac_lifecoaching`.`wp_users`' at line 1)

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
